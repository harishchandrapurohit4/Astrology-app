import { useEffect, useState } from 'react';
import {
  Wallet as WalletIcon,
  Plus,
  ArrowUpRight,
  ArrowDownLeft,
  Clock,
  CheckCircle,
  ShieldCheck,
  Zap,
  Gift,
} from 'lucide-react';
import { supabase } from '../lib/supabase';
import { useAuth } from '../contexts/AuthContext';
import { WalletTransaction } from '../types';

declare global {
  interface Window {
    Razorpay: new (options: RazorpayOptions) => RazorpayInstance;
  }
}

interface RazorpayOptions {
  key: string;
  amount: number;
  currency: string;
  name: string;
  description: string;
  order_id: string;
  theme: { color: string };
  prefill?: { name?: string; email?: string };
  handler: (response: RazorpayResponse) => void;
  modal?: { ondismiss?: () => void };
}

interface RazorpayResponse {
  razorpay_payment_id: string;
  razorpay_order_id: string;
  razorpay_signature: string;
}

interface RazorpayInstance {
  open: () => void;
}

const RECHARGE_OPTIONS = [
  { amount: 100, bonus: 0, label: 'Starter' },
  { amount: 200, bonus: 10, label: 'Basic' },
  { amount: 500, bonus: 50, label: 'Popular' },
  { amount: 1000, bonus: 150, label: 'Value' },
  { amount: 2000, bonus: 400, label: 'Premium' },
  { amount: 5000, bonus: 1250, label: 'Elite' },
];

function loadRazorpayScript(): Promise<boolean> {
  return new Promise((resolve) => {
    if (document.getElementById('razorpay-script')) {
      resolve(true);
      return;
    }
    const script = document.createElement('script');
    script.id = 'razorpay-script';
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function Wallet() {
  const { wallet, refreshWallet, user, profile } = useAuth();
  const [transactions, setTransactions] = useState<WalletTransaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [showRecharge, setShowRecharge] = useState(false);
  const [selectedAmount, setSelectedAmount] = useState<number | null>(null);
  const [customAmount, setCustomAmount] = useState('');
  const [processing, setProcessing] = useState(false);
  const [paymentStatus, setPaymentStatus] = useState<'idle' | 'success' | 'failed'>('idle');

  useEffect(() => {
    if (wallet) fetchTransactions();
  }, [wallet]);

  const fetchTransactions = async () => {
    if (!wallet) return;
    const { data } = await supabase
      .from('wallet_transactions')
      .select('*')
      .eq('wallet_id', wallet.id)
      .order('created_at', { ascending: false })
      .limit(20);
    setTransactions(data || []);
    setLoading(false);
  };

  const getEffectiveAmount = () => {
    if (selectedAmount) return selectedAmount;
    const parsed = parseFloat(customAmount);
    return isNaN(parsed) ? 0 : parsed;
  };

  const getBonusAmount = (amount: number) => {
    return RECHARGE_OPTIONS.find((o) => o.amount === amount)?.bonus || 0;
  };

  const handlePay = async () => {
    const amount = getEffectiveAmount();
    if (!amount || amount < 10 || !wallet) return;

    setProcessing(true);
    setPaymentStatus('idle');

    const scriptLoaded = await loadRazorpayScript();
    if (!scriptLoaded) {
      setProcessing(false);
      alert('Failed to load payment gateway. Please try again.');
      return;
    }

    try {
      const { data: sessionData } = await supabase.auth.getSession();
      const token = sessionData?.session?.access_token;

      const res = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/create-razorpay-order`,
        {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${token}`,
            Apikey: import.meta.env.VITE_SUPABASE_ANON_KEY,
          },
          body: JSON.stringify({ amount, currency: 'INR' }),
        }
      );

      const orderData = await res.json();

      if (!res.ok || orderData.error) {
        throw new Error(orderData.error || 'Order creation failed');
      }

      const bonus = getBonusAmount(amount);
      const totalCredit = amount + bonus;

      const options: RazorpayOptions = {
        key: orderData.keyId,
        amount: orderData.amount,
        currency: orderData.currency,
        name: 'AstroConnect',
        description: 'Wallet Recharge',
        order_id: orderData.orderId,
        theme: { color: '#f59e0b' },
        prefill: {
          name: profile?.full_name || '',
          email: user?.email || '',
        },
        handler: async (_response: RazorpayResponse) => {
          await supabase.from('wallet_transactions').insert({
            wallet_id: wallet.id,
            amount: totalCredit,
            transaction_type: 'credit',
            description:
              bonus > 0
                ? `Recharge of INR ${amount} + Bonus INR ${bonus}`
                : `Wallet Recharge of INR ${amount}`,
          });

          await supabase
            .from('wallets')
            .update({ balance: wallet.balance + totalCredit })
            .eq('id', wallet.id);

          await refreshWallet();
          await fetchTransactions();
          setPaymentStatus('success');
          setShowRecharge(false);
          setSelectedAmount(null);
          setCustomAmount('');
          setProcessing(false);
        },
        modal: {
          ondismiss: () => {
            setProcessing(false);
          },
        },
      };

      const rzp = new window.Razorpay(options);
      rzp.open();
    } catch (err: unknown) {
      const message = err instanceof Error ? err.message : 'Payment failed';
      console.error(message);
      setPaymentStatus('failed');
      setProcessing(false);
    }
  };

  const effectiveAmount = getEffectiveAmount();
  const bonus = getBonusAmount(effectiveAmount);
  const totalCredit = effectiveAmount + bonus;

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="bg-gradient-to-r from-slate-900 via-slate-800 to-slate-900 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="flex items-center gap-4 mb-8">
              <div className="w-16 h-16 bg-gradient-to-br from-amber-400 to-amber-600 rounded-2xl flex items-center justify-center shadow-lg shadow-amber-500/30">
                <WalletIcon className="w-8 h-8 text-white" />
              </div>
              <div>
                <h1 className="text-3xl font-bold">My Wallet</h1>
                <p className="text-gray-400">Manage your credits and transactions</p>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-6">
              <div className="bg-gradient-to-br from-amber-500 to-amber-700 rounded-2xl p-6 shadow-xl shadow-amber-900/30">
                <p className="text-amber-100 mb-1 text-sm font-medium uppercase tracking-wide">Available Balance</p>
                <p className="text-4xl font-bold mb-6">
                  {wallet?.currency || 'INR'} {wallet?.balance?.toFixed(2) || '0.00'}
                </p>
                <button
                  onClick={() => { setShowRecharge(true); setPaymentStatus('idle'); }}
                  className="flex items-center gap-2 bg-white text-amber-700 px-6 py-3 rounded-xl font-semibold hover:bg-amber-50 transition-colors shadow-md"
                >
                  <Plus className="w-5 h-5" />
                  Add Money
                </button>
              </div>

              <div className="bg-white/10 backdrop-blur rounded-2xl p-6 border border-white/10">
                <p className="text-gray-300 mb-4 text-sm font-medium uppercase tracking-wide">Quick Stats</p>
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-2xl font-bold text-green-400">
                      +{transactions
                        .filter((t) => t.transaction_type === 'credit')
                        .reduce((sum, t) => sum + t.amount, 0)
                        .toFixed(0)}
                    </p>
                    <p className="text-sm text-gray-400 mt-1">Total Credits</p>
                  </div>
                  <div>
                    <p className="text-2xl font-bold text-red-400">
                      -{transactions
                        .filter((t) => t.transaction_type === 'debit')
                        .reduce((sum, t) => sum + t.amount, 0)
                        .toFixed(0)}
                    </p>
                    <p className="text-sm text-gray-400 mt-1">Total Spent</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {paymentStatus === 'success' && (
        <div className="container mx-auto px-4 pt-6">
          <div className="max-w-4xl mx-auto">
            <div className="bg-green-50 border border-green-200 rounded-2xl p-4 flex items-center gap-3">
              <CheckCircle className="w-6 h-6 text-green-600 shrink-0" />
              <div>
                <p className="font-semibold text-green-800">Payment Successful!</p>
                <p className="text-sm text-green-600">Your wallet has been recharged successfully.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      {paymentStatus === 'failed' && (
        <div className="container mx-auto px-4 pt-6">
          <div className="max-w-4xl mx-auto">
            <div className="bg-red-50 border border-red-200 rounded-2xl p-4 flex items-center gap-3">
              <ShieldCheck className="w-6 h-6 text-red-600 shrink-0" />
              <div>
                <p className="font-semibold text-red-800">Payment Failed</p>
                <p className="text-sm text-red-600">Something went wrong. Please try again.</p>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <div className="bg-white rounded-2xl shadow-sm border border-gray-100">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-800">Transaction History</h2>
            </div>

            {loading ? (
              <div className="p-8 text-center">
                <div className="w-8 h-8 border-4 border-amber-200 border-t-amber-500 rounded-full animate-spin mx-auto" />
              </div>
            ) : transactions.length > 0 ? (
              <div className="divide-y divide-gray-50">
                {transactions.map((transaction) => (
                  <div key={transaction.id} className="p-6 flex items-center justify-between hover:bg-gray-50 transition-colors">
                    <div className="flex items-center gap-4">
                      <div
                        className={`w-12 h-12 rounded-full flex items-center justify-center ${
                          transaction.transaction_type === 'credit'
                            ? 'bg-green-100 text-green-600'
                            : transaction.transaction_type === 'refund'
                            ? 'bg-blue-100 text-blue-600'
                            : 'bg-red-100 text-red-600'
                        }`}
                      >
                        {transaction.transaction_type === 'debit' ? (
                          <ArrowUpRight className="w-6 h-6" />
                        ) : (
                          <ArrowDownLeft className="w-6 h-6" />
                        )}
                      </div>
                      <div>
                        <p className="font-semibold text-gray-800">
                          {transaction.description ||
                            (transaction.transaction_type === 'credit' ? 'Money Added' : 'Consultation Payment')}
                        </p>
                        <p className="text-sm text-gray-400 flex items-center gap-1 mt-0.5">
                          <Clock className="w-3.5 h-3.5" />
                          {new Date(transaction.created_at).toLocaleDateString('en-IN', {
                            day: 'numeric',
                            month: 'short',
                            year: 'numeric',
                          })}{' '}
                          at{' '}
                          {new Date(transaction.created_at).toLocaleTimeString('en-IN', {
                            hour: '2-digit',
                            minute: '2-digit',
                          })}
                        </p>
                      </div>
                    </div>
                    <div className="text-right">
                      <p
                        className={`text-xl font-bold ${
                          transaction.transaction_type === 'debit' ? 'text-red-600' : 'text-green-600'
                        }`}
                      >
                        {transaction.transaction_type === 'debit' ? '-' : '+'}INR{' '}
                        {transaction.amount.toFixed(2)}
                      </p>
                      <span className="inline-flex items-center gap-1 text-xs text-green-600 mt-1">
                        <CheckCircle className="w-3 h-3" />
                        Completed
                      </span>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="p-12 text-center">
                <WalletIcon className="w-16 h-16 text-gray-200 mx-auto mb-4" />
                <p className="text-gray-400 mb-2 font-medium">No transactions yet</p>
                <p className="text-gray-400 text-sm mb-6">Add money to get started</p>
                <button
                  onClick={() => setShowRecharge(true)}
                  className="inline-flex items-center gap-2 bg-amber-500 text-white px-6 py-3 rounded-xl font-semibold hover:bg-amber-600 transition-colors"
                >
                  <Plus className="w-5 h-5" />
                  Add Money
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {showRecharge && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-2xl w-full max-w-lg shadow-2xl max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-100">
              <h2 className="text-xl font-bold text-gray-900">Recharge Wallet</h2>
              <p className="text-gray-500 text-sm mt-1">Select an amount or enter a custom value</p>
            </div>

            <div className="p-6">
              <div className="grid grid-cols-2 gap-3 mb-6">
                {RECHARGE_OPTIONS.map((option) => (
                  <button
                    key={option.amount}
                    onClick={() => {
                      setSelectedAmount(option.amount);
                      setCustomAmount('');
                    }}
                    className={`relative p-4 rounded-xl border-2 transition-all text-left ${
                      selectedAmount === option.amount
                        ? 'border-amber-500 bg-amber-50'
                        : 'border-gray-200 hover:border-amber-300 hover:bg-amber-50/40'
                    }`}
                  >
                    {option.label === 'Popular' && (
                      <span className="absolute -top-2 right-3 bg-amber-500 text-white text-xs px-2 py-0.5 rounded-full font-semibold">
                        Popular
                      </span>
                    )}
                    <p className="text-lg font-bold text-gray-900">INR {option.amount}</p>
                    {option.bonus > 0 ? (
                      <p className="text-xs text-green-600 font-medium flex items-center gap-1 mt-1">
                        <Gift className="w-3 h-3" />
                        + INR {option.bonus} Bonus
                      </p>
                    ) : (
                      <p className="text-xs text-gray-400 mt-1">{option.label}</p>
                    )}
                  </button>
                ))}
              </div>

              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Or enter custom amount
                </label>
                <div className="relative">
                  <span className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400 font-medium text-sm">
                    INR
                  </span>
                  <input
                    type="number"
                    value={customAmount}
                    onChange={(e) => {
                      setCustomAmount(e.target.value);
                      setSelectedAmount(null);
                    }}
                    placeholder="Enter amount (min. 10)"
                    min="10"
                    className="w-full pl-14 pr-4 py-3 border border-gray-200 rounded-xl focus:ring-2 focus:ring-amber-400 focus:border-amber-400 outline-none transition"
                  />
                </div>
              </div>

              {effectiveAmount >= 10 && (
                <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-6">
                  <div className="flex justify-between text-sm mb-1">
                    <span className="text-gray-600">Amount</span>
                    <span className="font-semibold text-gray-900">INR {effectiveAmount.toFixed(2)}</span>
                  </div>
                  {bonus > 0 && (
                    <div className="flex justify-between text-sm mb-1">
                      <span className="text-green-600 flex items-center gap-1">
                        <Gift className="w-3.5 h-3.5" /> Bonus
                      </span>
                      <span className="font-semibold text-green-600">+ INR {bonus.toFixed(2)}</span>
                    </div>
                  )}
                  <div className="flex justify-between text-sm font-bold border-t border-amber-200 pt-2 mt-2">
                    <span className="text-gray-900">Total Credit</span>
                    <span className="text-amber-700">INR {totalCredit.toFixed(2)}</span>
                  </div>
                </div>
              )}

              <div className="flex items-center gap-3 text-gray-500 text-sm mb-6 bg-gray-50 rounded-xl p-4">
                <ShieldCheck className="w-5 h-5 text-green-600 shrink-0" />
                <span>Secured by Razorpay. 100% safe & encrypted payment.</span>
                <Zap className="w-4 h-4 text-amber-500 shrink-0 ml-auto" />
              </div>

              <div className="flex gap-3">
                <button
                  onClick={() => {
                    setShowRecharge(false);
                    setSelectedAmount(null);
                    setCustomAmount('');
                    setPaymentStatus('idle');
                  }}
                  className="flex-1 px-4 py-3 border border-gray-200 rounded-xl font-semibold text-gray-700 hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  onClick={handlePay}
                  disabled={processing || effectiveAmount < 10}
                  className="flex-1 bg-gradient-to-r from-amber-500 to-amber-600 text-white px-4 py-3 rounded-xl font-semibold hover:from-amber-600 hover:to-amber-700 transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-md shadow-amber-200"
                >
                  {processing ? (
                    <span className="flex items-center justify-center gap-2">
                      <span className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Processing...
                    </span>
                  ) : (
                    `Pay INR ${effectiveAmount >= 10 ? effectiveAmount.toFixed(0) : '0'}`
                  )}
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
