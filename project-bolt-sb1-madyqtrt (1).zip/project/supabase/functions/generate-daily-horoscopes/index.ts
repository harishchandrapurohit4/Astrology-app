import "jsr:@supabase/functions-js/edge-runtime.d.ts";
import { createClient } from "npm:@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

const ASTRO_API_BASE = "https://json.astrologyapi.com/v1";

const SIGN_MAP: Record<string, string> = {
  mesh: "aries",
  vrishabh: "taurus",
  mithun: "gemini",
  kark: "cancer",
  singh: "leo",
  kanya: "virgo",
  tula: "libra",
  vrishchik: "scorpio",
  dhanu: "sagittarius",
  makar: "capricorn",
  kumbh: "aquarius",
  meen: "pisces",
};

const SIGNS = Object.keys(SIGN_MAP);

const SIGN_META: Record<string, { color: string; number: string }> = {
  mesh:      { color: "Lal", number: "9" },
  vrishabh:  { color: "Hara", number: "6" },
  mithun:    { color: "Peela", number: "5" },
  kark:      { color: "Safed", number: "2" },
  singh:     { color: "Sona", number: "1" },
  kanya:     { color: "Neela", number: "5" },
  tula:      { color: "Gulabi", number: "6" },
  vrishchik: { color: "Gahra Lal", number: "8" },
  dhanu:     { color: "Neela", number: "3" },
  makar:     { color: "Bhura", number: "8" },
  kumbh:     { color: "Neela", number: "4" },
  meen:      { color: "Saamudri Hara", number: "7" },
};

const PLANETS: Record<string, string> = {
  mesh: "Mangal", vrishabh: "Shukra", mithun: "Budh", kark: "Chandra",
  singh: "Surya", kanya: "Budh", tula: "Shukra", vrishchik: "Mangal",
  dhanu: "Guru", makar: "Shani", kumbh: "Shani", meen: "Guru",
};

const GENERAL_TEMPLATES = [
  (p: string) => `Aaj ${p} ki vishesh anukampa aap par bani hui hai. Din ki shuruat urja se bharpoor rahegi aur karyasthali mein aapke prayas safal honge.`,
  (p: string) => `${p} ki drishti aaj aapke jeevan mein nayi roshni lekar aayi hai. Naye avsar dwaar khatkhatate hain — unhe dhyan se dekhein.`,
  (p: string) => `${p} ki kripa se aaj ka din bahut shubh hai. Kisi bhi naye kaam ki shuruat ke liye yeh divas uttam hai.`,
  (p: string) => `Aaj ${p} aapki rashi par vishesh drishti rakh rahe hain. Apni pratibha ka pura upayog karen.`,
  (p: string) => `${p} ke prabhav se aaj aapke andar ek nai urja ka sanchaar hoga. Apne lakshya par dhyan lagayen.`,
  (p: string) => `Aaj ${p} ki shakti aapko har chunauti par vijay dilayegi. Mann mein shanti banaye rakhein.`,
  (p: string) => `${p} graha aaj aapke paksh mein hai. Jo kaam ruke hue the, woh aaj poore ho sakte hain.`,
];

const LOVE_T = [
  "Prem jeevan mein meetha waqt aayega. Saathi ke saath kuch vishesh samay bitayen.",
  "Rishton mein nayi taazgi aayegi. Partner ki baat dhyaan se sunein.",
  "Aaj prem mein ek nayi umang ka anubhav hoga. Chhoti si khushi badi yaad ban sakti hai.",
  "Apne priyajan ke liye kuch khaas karne ka yeh achha mauka hai.",
  "Prem mein thoda samjhauta karna aaj laabhdaayak rahega.",
  "Naye prem rishte ka avsar aa sakta hai. Khule dil se milein.",
  "Purana rishta aur gehraata badhega. Vishwaas aur samman banaye rakhein.",
];

const CAREER_T = [
  "Karyasthali mein aapki mehnat ko pahchaana jaayega. Boss ki prashansa milegi.",
  "Koi naya project ya zimmedari milne ke yog hain. Ise sevaabhav se sweekar karen.",
  "Teamwork mein aaj behtar results milenge. Sahakarmion ka saath labhdaayak rahega.",
  "Vyapar mein naya sauda ya contract milne ki sambhavana hai.",
  "Aaj kisi bhi mahtvapurna kaam ko poora karne ka din hai. Focus rakhen.",
  "Career mein ek bada nirnay lene ka samay aa gaya hai.",
  "Office mein aapka prabhav aaj zyada dikhai dega.",
];

const FINANCE_T = [
  "Aarthik sthiti theek rahegi. Koi purana bhagtaan aaj hal ho sakta hai.",
  "Dhana laabh ki sambhavana hai — sahi jagah nivesh karen.",
  "Chhote chhote kharche jodne se bada niqsaan ho sakta hai, dhyan rakhen.",
  "Aaj vyapar mein laabh ki sambhavana hai.",
  "Nivesh ke liye aaj ka din prateeksha ka hai.",
  "Aarthik maamlon mein saavdhani zaroori hai.",
  "Kisi se paisa lenaa-denaa aaj carefully karen.",
];

const HEALTH_T = [
  "Sar dard se bachne ke liye paani zyada piyen. Vyayam aaj bahut labhdaayak rahega.",
  "Aahaar par dhyaan den. Poshak aahar len.",
  "Neend poori len — thakaan mehsoos ho sakti hai.",
  "Antra ki sehat ka dhyaan rakhein.",
  "Tanav se bachne ke liye meditation ya praanayaam karen.",
  "Paet ki samasyaon se savdhaan rahein. Halka aur saatvik aahar len.",
  "Hriday ki sehat ka dhyaan rakhein.",
];

const SCORES = [
  [3,4,3,4],[4,5,3,3],[5,4,4,3],[3,3,5,4],
  [4,4,4,3],[5,3,3,4],[3,5,4,3],[4,4,5,3],
  [3,4,4,5],[4,5,3,3],[5,4,4,4],[4,3,5,3],
];

function seededInt(seed: number, max: number): number {
  const x = Math.sin(seed) * 10000;
  return Math.floor((x - Math.floor(x)) * max);
}

function generateFallback(sign: string, dateStr: string) {
  const signIndex = SIGNS.indexOf(sign);
  const dateSeed = dateStr.split("-").reduce((acc, v) => acc + parseInt(v), 0);
  const seed = dateSeed * 31 + signIndex * 17;
  const scoreSet = SCORES[(seed + signIndex) % SCORES.length];
  const meta = SIGN_META[sign];
  return {
    sign, date: dateStr, source: "generated",
    general: GENERAL_TEMPLATES[seededInt(seed + 1, GENERAL_TEMPLATES.length)](PLANETS[sign]),
    love: LOVE_T[seededInt(seed + 2, LOVE_T.length)],
    career: CAREER_T[seededInt(seed + 3, CAREER_T.length)],
    finance: FINANCE_T[seededInt(seed + 4, FINANCE_T.length)],
    health: HEALTH_T[seededInt(seed + 5, HEALTH_T.length)],
    score_love: scoreSet[0], score_career: scoreSet[1],
    score_finance: scoreSet[2], score_health: scoreSet[3],
    lucky_color: meta.color, lucky_number: meta.number,
  };
}

const TITHI_HINDI: Record<string, string> = {
  "Shukla-Pratipada":"शुक्ल प्रतिपदा","Shukla-Dwitiya":"शुक्ल द्वितीया","Shukla-Tritiya":"शुक्ल तृतीया",
  "Shukla-Chaturthi":"शुक्ल चतुर्थी","Shukla-Panchami":"शुक्ल पंचमी","Shukla-Shashthi":"शुक्ल षष्ठी",
  "Shukla-Saptami":"शुक्ल सप्तमी","Shukla-Ashtami":"शुक्ल अष्टमी","Shukla-Navami":"शुक्ल नवमी",
  "Shukla-Dashami":"शुक्ल दशमी","Shukla-Ekadashi":"शुक्ल एकादशी","Shukla-Dwadashi":"शुक्ल द्वादशी",
  "Shukla-Trayodashi":"शुक्ल त्रयोदशी","Shukla-Chaturdashi":"शुक्ल चतुर्दशी","Purnima":"पूर्णिमा",
  "Krishna-Pratipada":"कृष्ण प्रतिपदा","Krishna-Dwitiya":"कृष्ण द्वितीया","Krishna-Tritiya":"कृष्ण तृतीया",
  "Krishna-Chaturthi":"कृष्ण चतुर्थी","Krishna-Panchami":"कृष्ण पंचमी","Krishna-Shashthi":"कृष्ण षष्ठी",
  "Krishna-Saptami":"कृष्ण सप्तमी","Krishna-Ashtami":"कृष्ण अष्टमी","Krishna-Navami":"कृष्ण नवमी",
  "Krishna-Dashami":"कृष्ण दशमी","Krishna-Ekadashi":"कृष्ण एकादशी","Krishna-Dwadashi":"कृष्ण द्वादशी",
  "Krishna-Trayodashi":"कृष्ण त्रयोदशी","Krishna-Chaturdashi":"कृष्ण चतुर्दशी","Amavasya":"अमावस्या",
};

const NAKSHATRA_HINDI: Record<string, string> = {
  "Ashwini":"अश्विनी","Bharani":"भरणी","Krittika":"कृत्तिका","Rohini":"रोहिणी","Mrigashira":"मृगशिरा",
  "Ardra":"आर्द्रा","Punarvasu":"पुनर्वसु","Pushya":"पुष्य","Ashlesha":"आश्लेषा","Magha":"मघा",
  "Purva Phalguni":"पूर्वा फाल्गुनी","Uttara Phalguni":"उत्तरा फाल्गुनी","Hasta":"हस्त","Chitra":"चित्रा",
  "Swati":"स्वाति","Vishakha":"विशाखा","Anuradha":"अनुराधा","Jyeshtha":"ज्येष्ठा","Mula":"मूल",
  "Purva Ashadha":"पूर्वाषाढ़ा","Uttara Ashadha":"उत्तराषाढ़ा","Shravana":"श्रवण","Dhanistha":"धनिष्ठा",
  "Shatabhisha":"शतभिषा","Purva Bhadrapada":"पूर्वा भाद्रपद","Uttara Bhadrapada":"उत्तरा भाद्रपद","Revati":"रेवती",
};

const YOG_HINDI: Record<string, string> = {
  "Vishkambha":"विष्कम्भ","Preeti":"प्रीति","Ayushman":"आयुष्मान","Saubhagya":"सौभाग्य",
  "Shobhana":"शोभन","Atiganda":"अतिगण्ड","Sukarma":"सुकर्मा","Dhriti":"धृति",
  "Shoola":"शूल","Ganda":"गण्ड","Vriddhi":"वृद्धि","Dhruva":"ध्रुव",
  "Vyaghata":"व्याघात","Harshana":"हर्षण","Vajra":"वज्र","Siddhi":"सिद्धि",
  "Vyatipata":"व्यतीपात","Variyana":"वरीयान","Parigha":"परिघ","Shiva":"शिव",
  "Siddha":"सिद्ध","Sadhya":"साध्य","Shubha":"शुभ","Shukla":"शुक्ल",
  "Brahma":"ब्रह्म","Indra":"इन्द्र","Vaidhriti":"वैधृति",
};

const DAY_HINDI: Record<string, string> = {
  "Sunday":"रविवार","Monday":"सोमवार","Tuesday":"मंगलवार","Wednesday":"बुधवार",
  "Thursday":"गुरुवार","Friday":"शुक्रवार","Saturday":"शनिवार",
};

function toHindi(val: string, map: Record<string, string>): string {
  return map[val] || val;
}

async function fetchPanchang(token: string, now: Date): Promise<Record<string, string> | null> {
  const body = {
    day: now.getDate(),
    month: now.getMonth() + 1,
    year: now.getFullYear(),
    hour: now.getHours(),
    min: now.getMinutes(),
    lat: 28.6139,
    lon: 77.2090,
    tzone: 5.5,
  };

  try {
    const res = await fetch(`${ASTRO_API_BASE}/basic_panchang`, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${token}`,
        "Content-Type": "application/json",
        "Accept-Language": "hi",
      },
      body: JSON.stringify(body),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

async function fetchHoroscope(token: string, sign: string): Promise<Record<string, string> | null> {
  const apiSign = SIGN_MAP[sign];
  try {
    const res = await fetch(`${ASTRO_API_BASE}/sun_sign_prediction/daily/${apiSign}`, {
      method: "POST",
      headers: {
        "Authorization": `Basic ${token}`,
        "Content-Type": "application/json",
        "Accept-Language": "hi",
      },
      body: JSON.stringify({}),
    });
    if (!res.ok) return null;
    return await res.json();
  } catch {
    return null;
  }
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 200, headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const astroToken = Deno.env.get("ASTROLOGY_API_TOKEN") || "";

    const supabase = createClient(supabaseUrl, serviceRoleKey);
    const now = new Date();
    const dateStr = now.toISOString().split("T")[0];

    const [panchangData] = await Promise.all([
      fetchPanchang(astroToken, now),
    ]);

    const TITHI_LIST = Object.values(TITHI_HINDI);
    const NAKSHATRA_LIST = Object.values(NAKSHATRA_HINDI);
    const YOG_LIST = Object.values(YOG_HINDI);
    const DAY_LIST = Object.values(DAY_HINDI);
    const dateSeedP = now.getFullYear() * 10000 + (now.getMonth() + 1) * 100 + now.getDate();
    const tithiIdx = dateSeedP % TITHI_LIST.length;
    const nakshatraIdx = (dateSeedP * 7) % NAKSHATRA_LIST.length;
    const yogIdx = (dateSeedP * 13) % YOG_LIST.length;
    const dayIdx = now.getDay();
    const fallbackPanchang = {
      date: dateStr,
      tithi: TITHI_LIST[tithiIdx],
      nakshatra: NAKSHATRA_LIST[nakshatraIdx],
      yog: YOG_LIST[yogIdx],
      karan: "",
      sunrise: "6:15",
      sunset: "18:30",
      day_name: DAY_LIST[dayIdx],
    };

    if (panchangData && panchangData.tithi) {
      const panchangRow = {
        date: dateStr,
        tithi: toHindi(panchangData.tithi, TITHI_HINDI),
        nakshatra: toHindi(panchangData.nakshatra, NAKSHATRA_HINDI),
        yog: toHindi(panchangData.yog, YOG_HINDI),
        karan: panchangData.karan || "",
        sunrise: panchangData.sunrise || "",
        sunset: panchangData.sunset || "",
        day_name: toHindi(panchangData.day, DAY_HINDI),
      };
      await supabase.from("daily_panchang").upsert(panchangRow, { onConflict: "date" });
    } else {
      await supabase.from("daily_panchang").upsert(fallbackPanchang, { onConflict: "date" });
    }

    const horoscopes = await Promise.all(
      SIGNS.map(async (sign) => {
        const apiData = await fetchHoroscope(astroToken, sign);
        const meta = SIGN_META[sign];
        const fallback = generateFallback(sign, dateStr);

        if (apiData && (apiData.prediction_date || apiData.bot_response)) {
          const prediction = apiData.bot_response || apiData.prediction || "";
          const personal = apiData.personal_life || "";
          const prof = apiData.profession || "";
          const fin = apiData.finances || "";
          const health = apiData.health || "";

          if (prediction) {
            return {
              sign, date: dateStr, source: "api",
              general: prediction,
              love: personal || fallback.love,
              career: prof || fallback.career,
              finance: fin || fallback.finance,
              health: health || fallback.health,
              score_love: fallback.score_love,
              score_career: fallback.score_career,
              score_finance: fallback.score_finance,
              score_health: fallback.score_health,
              lucky_color: apiData.lucky_color || meta.color,
              lucky_number: apiData.lucky_number || meta.number,
            };
          }
        }
        return fallback;
      })
    );

    const { error } = await supabase
      .from("daily_horoscopes")
      .upsert(horoscopes, { onConflict: "sign,date" });

    if (error) {
      return new Response(
        JSON.stringify({ error: error.message }),
        { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
      );
    }

    return new Response(
      JSON.stringify({ success: true, date: dateStr, count: horoscopes.length }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (err) {
    const msg = err instanceof Error ? err.message : "Internal server error";
    return new Response(
      JSON.stringify({ error: msg }),
      { status: 500, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
