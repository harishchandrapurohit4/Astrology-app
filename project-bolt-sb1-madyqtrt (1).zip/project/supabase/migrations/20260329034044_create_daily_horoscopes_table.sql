/*
  # Create Daily Horoscopes Table

  ## Purpose
  Stores auto-generated daily horoscope content for all 12 Vedic moon signs.
  The table is keyed by (sign, date) so each sign gets one entry per day.

  ## New Tables
  - `daily_horoscopes`
    - `id` (uuid, primary key)
    - `sign` (text) - moon sign key e.g. 'mesh', 'vrishabh'
    - `date` (date) - the calendar date this horoscope applies to
    - `general` (text) - general prediction
    - `love` (text) - love & relationship prediction
    - `career` (text) - career prediction
    - `finance` (text) - finance prediction
    - `health` (text) - health prediction
    - `score_love` (int) - 1-5 star score
    - `score_career` (int) - 1-5 star score
    - `score_finance` (int) - 1-5 star score
    - `score_health` (int) - 1-5 star score
    - `lucky_color` (text)
    - `lucky_number` (text)
    - `created_at` (timestamptz)
    - Unique constraint on (sign, date)

  ## Security
  - RLS enabled
  - Public read policy (horoscopes are public content)
  - No direct write policy for users (written only by service role via edge function)
*/

CREATE TABLE IF NOT EXISTS daily_horoscopes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  sign text NOT NULL,
  date date NOT NULL,
  general text NOT NULL DEFAULT '',
  love text NOT NULL DEFAULT '',
  career text NOT NULL DEFAULT '',
  finance text NOT NULL DEFAULT '',
  health text NOT NULL DEFAULT '',
  score_love integer NOT NULL DEFAULT 3 CHECK (score_love >= 1 AND score_love <= 5),
  score_career integer NOT NULL DEFAULT 3 CHECK (score_career >= 1 AND score_career <= 5),
  score_finance integer NOT NULL DEFAULT 3 CHECK (score_finance >= 1 AND score_finance <= 5),
  score_health integer NOT NULL DEFAULT 3 CHECK (score_health >= 1 AND score_health <= 5),
  lucky_color text NOT NULL DEFAULT '',
  lucky_number text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS daily_horoscopes_sign_date_idx ON daily_horoscopes (sign, date);

ALTER TABLE daily_horoscopes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read daily horoscopes"
  ON daily_horoscopes
  FOR SELECT
  TO anon, authenticated
  USING (true);
