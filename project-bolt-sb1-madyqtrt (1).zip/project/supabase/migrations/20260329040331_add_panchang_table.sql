/*
  # Create Daily Panchang Table

  ## Purpose
  Stores daily Panchang data (Tithi, Nakshatra, Yog, Karan, Sunrise, Sunset)
  fetched from AstrologyAPI.com. Keyed by date for one entry per day.

  ## New Tables
  - `daily_panchang`
    - `id` (uuid, primary key)
    - `date` (date, unique) — the calendar date
    - `tithi` (text) — lunar day
    - `nakshatra` (text) — lunar mansion
    - `yog` (text) — yoga
    - `karan` (text) — karan
    - `sunrise` (text)
    - `sunset` (text)
    - `day_name` (text) — weekday
    - `created_at` (timestamptz)

  ## Security
  - RLS enabled
  - Public read (panchang is public information)
  - No direct user writes (written only by service role via edge function)
*/

CREATE TABLE IF NOT EXISTS daily_panchang (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  date date NOT NULL UNIQUE,
  tithi text NOT NULL DEFAULT '',
  nakshatra text NOT NULL DEFAULT '',
  yog text NOT NULL DEFAULT '',
  karan text NOT NULL DEFAULT '',
  sunrise text NOT NULL DEFAULT '',
  sunset text NOT NULL DEFAULT '',
  day_name text NOT NULL DEFAULT '',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE daily_panchang ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read daily panchang"
  ON daily_panchang
  FOR SELECT
  TO anon, authenticated
  USING (true);
