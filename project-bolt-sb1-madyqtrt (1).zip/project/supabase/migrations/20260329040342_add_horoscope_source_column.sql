/*
  # Add source column to daily_horoscopes

  Tracks whether content came from AstrologyAPI (real) or was generated locally (fallback).

  ## Changes
  - `daily_horoscopes`
    - Add `source` column (text): 'api' | 'generated'
*/

DO $$
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM information_schema.columns
    WHERE table_name = 'daily_horoscopes' AND column_name = 'source'
  ) THEN
    ALTER TABLE daily_horoscopes ADD COLUMN source text NOT NULL DEFAULT 'generated';
  END IF;
END $$;
