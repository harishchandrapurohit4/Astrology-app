import { useEffect, useState } from 'react';
import { TrendingUp, TrendingDown, Minus, Sun, Moon, Star, AlertTriangle, Info, Flame, Crown, Sparkles } from 'lucide-react';
import { supabase } from '../lib/supabase';

interface DailyPanchang {
  date: string;
  tithi: string;
  nakshatra: string;
  yog: string;
  sunrise: string;
  sunset: string;
  day_name: string;
}

interface PlanetConfig {
  id: string;
  planet: string;
  symbol: string;
  position: string;
  influence: 'bullish' | 'bearish' | 'neutral';
  sectors: string[];
  insight: string;
  strength: number;
  config_date: string;
}

interface NiftyZone {
  id: string;
  label: string;
  level: string;
  zone_type: 'support' | 'resistance' | 'current';
  sort_order: number;
  config_date: string;
}

interface TradingNote {
  id: string;
  note_text: string;
  config_date: string;
}

const FALLBACK_PLANETS: PlanetConfig[] = [
  { id: '1', planet: 'Sun', symbol: '☉', position: 'Aries (Exalted)', influence: 'bullish', sectors: ['Government Stocks', 'Gold', 'Energy'], insight: 'Surya uchch mein hai — sarkar aur energy sector mein taakat dikhne ki sambhavna.', strength: 85, config_date: '' },
  { id: '2', planet: 'Moon', symbol: '☽', position: 'Taurus', influence: 'bullish', sectors: ['FMCG', 'Real Estate', 'Silver'], insight: 'Chandra sthir rashi mein hai — FMCG aur real estate mein stability.', strength: 72, config_date: '' },
  { id: '3', planet: 'Mars', symbol: '♂', position: 'Gemini', influence: 'neutral', sectors: ['Tech', 'Automobiles', 'Defence'], insight: 'Mangal dual rashi mein — tech sector mein volatility sambhav.', strength: 55, config_date: '' },
  { id: '4', planet: 'Mercury', symbol: '☿', position: 'Pisces (Debilitated)', influence: 'bearish', sectors: ['IT', 'Media', 'Banking'], insight: 'Budh neech rashi mein — communication aur IT stocks mein confusion.', strength: 30, config_date: '' },
  { id: '5', planet: 'Jupiter', symbol: '♃', position: 'Taurus', influence: 'bullish', sectors: ['Finance', 'Education', 'Pharma'], insight: 'Guru sthir rashi mein — long-term investments ke liye shubh.', strength: 78, config_date: '' },
  { id: '6', planet: 'Venus', symbol: '♀', position: 'Pisces (Exalted)', influence: 'bullish', sectors: ['Luxury', 'Entertainment', 'Hospitality'], insight: 'Shukra uchch rashi mein — luxury brands aur entertainment sector mein tej chaal sambhav.', strength: 90, config_date: '' },
  { id: '7', planet: 'Saturn', symbol: '♄', position: 'Aquarius', influence: 'neutral', sectors: ['Infrastructure', 'Oil & Gas', 'Iron/Steel'], insight: 'Shani swagruhi — infrastructure mein dheemi lekin mazboot growth.', strength: 60, config_date: '' },
  { id: '8', planet: 'Rahu', symbol: '☊', position: 'Pisces', influence: 'bearish', sectors: ['Chemicals', 'Speculation', 'Crypto'], insight: 'Rahu Meen mein — speculative trades mein bharosa na kare.', strength: 25, config_date: '' },
];

const FALLBACK_ZONES: NiftyZone[] = [
  { id: '1', label: 'Strong Support', level: '21,800', zone_type: 'support', sort_order: 1, config_date: '' },
  { id: '2', label: 'Support', level: '22,150', zone_type: 'support', sort_order: 2, config_date: '' },
  { id: '3', label: 'Current Zone', level: '22,500', zone_type: 'current', sort_order: 3, config_date: '' },
  { id: '4', label: 'Resistance', level: '22,850', zone_type: 'resistance', sort_order: 4, config_date: '' },
  { id: '5', label: 'Strong Resistance', level: '23,200', zone_type: 'resistance', sort_order: 5, config_date: '' },
];

const WEEKLY_OUTLOOK_BASE = [
  { dayIndex: 1, day: 'Monday', ruler: 'Moon', mood: 'bullish', note: 'Trading shuru karne ke liye shubh din' },
  { dayIndex: 2, day: 'Tuesday', ruler: 'Mars', mood: 'volatile', note: 'High risk — caution zaroori' },
  { dayIndex: 3, day: 'Wednesday', ruler: 'Mercury', mood: 'bearish', note: 'IT & media stocks mein pressure' },
  { dayIndex: 4, day: 'Thursday', ruler: 'Jupiter', mood: 'bullish', note: 'Finance & pharma ke liye accha din' },
  { dayIndex: 5, day: 'Friday', ruler: 'Venus', mood: 'bullish', note: 'Luxury & FMCG mein positive movement' },
  { dayIndex: 6, day: 'Saturday', ruler: 'Saturn', mood: 'neutral', note: 'Infra stocks stable rahenge' },
  { dayIndex: 0, day: 'Sunday', ruler: 'Sun', mood: 'neutral', note: 'Market band — analysis ka din' },
];

const AUSPICIOUS_RASHIS = [
  { name: 'Vrishabh', symbol: '♉', reason: 'Shukra uchch + Guru sthit' },
  { name: 'Meen', symbol: '♓', reason: 'Shukra uchch rashi' },
  { name: 'Singh', symbol: '♌', reason: 'Surya swakshetri prabhav' },
];

function getOrderedWeekDays() {
  const todayIndex = new Date().getDay();
  const sorted = [...WEEKLY_OUTLOOK_BASE].sort((a, b) => {
    const ai = (a.dayIndex - todayIndex + 7) % 7;
    const bi = (b.dayIndex - todayIndex + 7) % 7;
    return ai - bi;
  });
  return sorted;
}

function InfluenceBadge({ influence }: { influence: string }) {
  if (influence === 'bullish') {
    return (
      <span className="inline-flex items-center gap-1 bg-emerald-100 text-emerald-700 text-xs font-semibold px-2.5 py-1 rounded-full">
        <TrendingUp className="w-3 h-3" /> Bullish
      </span>
    );
  }
  if (influence === 'bearish') {
    return (
      <span className="inline-flex items-center gap-1 bg-red-100 text-red-600 text-xs font-semibold px-2.5 py-1 rounded-full">
        <TrendingDown className="w-3 h-3" /> Bearish
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 bg-amber-100 text-amber-700 text-xs font-semibold px-2.5 py-1 rounded-full">
      <Minus className="w-3 h-3" /> Neutral
    </span>
  );
}

function MoodIcon({ mood }: { mood: string }) {
  if (mood === 'bullish') return <TrendingUp className="w-4 h-4 text-emerald-500" />;
  if (mood === 'bearish') return <TrendingDown className="w-4 h-4 text-red-500" />;
  return <AlertTriangle className="w-4 h-4 text-amber-500" />;
}

function GoldDivider() {
  return (
    <div className="flex items-center gap-3 my-8">
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />
      <Star className="w-4 h-4 text-amber-400" fill="currentColor" />
      <div className="flex-1 h-px bg-gradient-to-r from-transparent via-amber-400/50 to-transparent" />
    </div>
  );
}

export default function AstroTrading() {
  const [panchang, setPanchang] = useState<DailyPanchang | null>(null);
  const [panchangLoading, setPanchangLoading] = useState(true);
  const [planets, setPlanets] = useState<PlanetConfig[]>([]);
  const [niftyZones, setNiftyZones] = useState<NiftyZone[]>([]);
  const [tradingNote, setTradingNote] = useState<string>('');
  const [dataLoading, setDataLoading] = useState(true);

  const today = new Date().toLocaleDateString('hi-IN', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' });
  const todayStr = new Date().toISOString().split('T')[0];
  const weekDays = getOrderedWeekDays();
  const todayDayIndex = new Date().getDay();

  const activePlanets = planets.length > 0 ? planets : FALLBACK_PLANETS;
  const activeZones = niftyZones.length > 0 ? niftyZones : FALLBACK_ZONES;

  const bullishCount = activePlanets.filter(p => p.influence === 'bullish').length;
  const bearishCount = activePlanets.filter(p => p.influence === 'bearish').length;
  const overallMood = bullishCount > bearishCount ? 'Bullish' : bearishCount > bullishCount ? 'Bearish' : 'Neutral';

  useEffect(() => {
    supabase
      .from('daily_panchang')
      .select('*')
      .eq('date', todayStr)
      .maybeSingle()
      .then(({ data }) => {
        if (data) setPanchang(data as DailyPanchang);
        setPanchangLoading(false);
      });
  }, [todayStr]);

  useEffect(() => {
    setDataLoading(true);

    const fetchPlanets = supabase
      .from('astro_planet_config')
      .select('*')
      .eq('config_date', todayStr)
      .order('planet');

    const fetchZones = supabase
      .from('astro_nifty_zones')
      .select('*')
      .eq('config_date', todayStr)
      .order('sort_order');

    const fetchNote = supabase
      .from('astro_trading_notes')
      .select('*')
      .eq('config_date', todayStr)
      .maybeSingle();

    Promise.all([fetchPlanets, fetchZones, fetchNote]).then(([pRes, zRes, nRes]) => {
      if (pRes.data && pRes.data.length > 0) setPlanets(pRes.data as PlanetConfig[]);
      if (zRes.data && zRes.data.length > 0) setNiftyZones(zRes.data as NiftyZone[]);
      if (nRes.data) setTradingNote((nRes.data as TradingNote).note_text);
      setDataLoading(false);
    });
  }, [todayStr]);

  return (
    <div className="min-h-screen bg-[#0d0d14]">
      <div className="bg-gradient-to-br from-slate-900 via-slate-800 to-amber-950 text-white py-16 relative overflow-hidden">
        <div className="absolute inset-0 pointer-events-none">
          <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/60 to-transparent" />
          <div className="absolute -top-40 left-1/2 -translate-x-1/2 w-[600px] h-[400px] bg-amber-500/5 rounded-full blur-3xl" />
        </div>

        <div className="container mx-auto px-4 text-center relative z-10">
          <div className="inline-flex items-center gap-2 bg-amber-500/15 border border-amber-500/30 px-4 py-2 rounded-full mb-5">
            <Crown className="w-4 h-4 text-amber-400" />
            <span className="text-amber-300 text-sm font-medium">30 Saal ke Anubhav par Aadharit — Acharya Harish Purohit</span>
          </div>
          <h1 className="text-4xl md:text-5xl font-bold mb-4">
            Astro-Trading{' '}
            <span className="bg-gradient-to-r from-amber-300 to-amber-500 bg-clip-text text-transparent">
              Insights
            </span>
          </h1>
          <p className="text-gray-300 max-w-2xl mx-auto text-lg mb-2">
            Grahon ki chaal ke hisaab se Nifty/Sensex market ka mood samjhen
          </p>
          <p className="text-amber-400/70 text-sm">{today}</p>

          <div className="mt-8 inline-flex items-center gap-4 sm:gap-6 bg-white/5 backdrop-blur border border-amber-500/20 rounded-2xl px-6 py-4 shadow-[0_0_30px_rgba(251,191,36,0.08)]">
            <div className="text-center">
              <div className="text-2xl font-bold text-emerald-400">{bullishCount}</div>
              <div className="text-xs text-gray-400">Bullish Planets</div>
            </div>
            <div className="w-px h-10 bg-amber-500/30" />
            <div className="text-center">
              <div className="text-2xl font-bold text-red-400">{bearishCount}</div>
              <div className="text-xs text-gray-400">Bearish Planets</div>
            </div>
            <div className="w-px h-10 bg-amber-500/30" />
            <div className="text-center">
              <div className={`text-2xl font-bold ${overallMood === 'Bullish' ? 'text-emerald-400' : overallMood === 'Bearish' ? 'text-red-400' : 'text-amber-400'}`}>
                {overallMood}
              </div>
              <div className="text-xs text-gray-400">Overall Mood</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-amber-950/60 border-y border-amber-500/20 py-3">
        <div className="container mx-auto px-4 flex items-start gap-2 text-amber-200/80 text-sm">
          <Info className="w-4 h-4 mt-0.5 flex-shrink-0 text-amber-400" />
          <p>
            <strong className="text-amber-400">Disclaimer:</strong> Yeh insights keval jyotish shastra ke siddhanton par aadharit hain. Yeh financial advice nahi hai. Kisi bhi investment se pehle apne financial advisor se salah len.
          </p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10">

        <section className="mb-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1 h-8 bg-gradient-to-b from-amber-400 to-amber-600 rounded-full" />
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
                <Flame className="w-5 h-5 text-amber-400" />
                Live Trends — Aaj ki Jyotish Sthiti
              </h2>
              <p className="text-gray-400 text-sm">Real-time panchang aur shubh rashi ki jankari</p>
            </div>
          </div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
            <div className="relative rounded-2xl overflow-hidden border border-amber-500/40 bg-gradient-to-br from-slate-800 to-slate-900 shadow-[0_0_20px_rgba(251,191,36,0.1)]">
              <div className="absolute inset-0 rounded-2xl pointer-events-none ring-1 ring-inset ring-amber-400/20" />
              <div className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Moon className="w-5 h-5 text-amber-400" />
                  <span className="text-amber-400 font-semibold text-sm uppercase tracking-wide">Aaj ki Tithi</span>
                </div>
                {panchangLoading ? (
                  <div className="h-8 bg-white/10 rounded animate-pulse w-3/4" />
                ) : panchang ? (
                  <p className="text-white font-bold text-2xl">{panchang.tithi}</p>
                ) : (
                  <p className="text-gray-400 text-sm">Uplabdh nahi</p>
                )}
                {panchang && (
                  <p className="text-gray-400 text-xs mt-1">{panchang.day_name}</p>
                )}
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />
            </div>

            <div className="relative rounded-2xl overflow-hidden border border-amber-500/40 bg-gradient-to-br from-slate-800 to-slate-900 shadow-[0_0_20px_rgba(251,191,36,0.1)]">
              <div className="absolute inset-0 rounded-2xl pointer-events-none ring-1 ring-inset ring-amber-400/20" />
              <div className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Sparkles className="w-5 h-5 text-amber-400" />
                  <span className="text-amber-400 font-semibold text-sm uppercase tracking-wide">Nakshatra</span>
                </div>
                {panchangLoading ? (
                  <div className="h-8 bg-white/10 rounded animate-pulse w-3/4" />
                ) : panchang ? (
                  <p className="text-white font-bold text-2xl">{panchang.nakshatra}</p>
                ) : (
                  <p className="text-gray-400 text-sm">Uplabdh nahi</p>
                )}
                {panchang && (
                  <p className="text-gray-400 text-xs mt-1">Yog: {panchang.yog}</p>
                )}
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />
            </div>

            <div className="relative rounded-2xl overflow-hidden border border-amber-500/40 bg-gradient-to-br from-amber-900/40 to-slate-900 shadow-[0_0_20px_rgba(251,191,36,0.12)] sm:col-span-2 lg:col-span-1">
              <div className="absolute inset-0 rounded-2xl pointer-events-none ring-1 ring-inset ring-amber-400/30" />
              <div className="p-5">
                <div className="flex items-center gap-2 mb-3">
                  <Star className="w-5 h-5 text-amber-400" fill="currentColor" />
                  <span className="text-amber-400 font-semibold text-sm uppercase tracking-wide">Aaj ki Shubh Rashiyan</span>
                </div>
                <div className="space-y-2">
                  {AUSPICIOUS_RASHIS.map((r, i) => (
                    <div key={r.name} className="flex items-center gap-3">
                      <span className={`w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold flex-shrink-0 ${i === 0 ? 'bg-amber-500 text-slate-900' : 'bg-amber-500/20 text-amber-400'}`}>
                        {i + 1}
                      </span>
                      <span className="text-lg">{r.symbol}</span>
                      <div className="min-w-0">
                        <p className="text-white font-semibold text-sm leading-none">{r.name}</p>
                        <p className="text-gray-400 text-xs truncate">{r.reason}</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />
            </div>
          </div>
        </section>

        <GoldDivider />

        <section className="mb-10">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-1 h-8 bg-gradient-to-b from-amber-400 to-amber-600 rounded-full" />
            <div>
              <h2 className="text-xl sm:text-2xl font-bold text-white flex items-center gap-2">
                <Sun className="w-5 h-5 text-amber-400" />
                Graha Prabhav — Sector-wise Analysis
              </h2>
              <p className="text-gray-400 text-sm">Aaj ke grahon ki sthiti aur unka market par prabhav</p>
            </div>
          </div>

          {dataLoading ? (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {[...Array(8)].map((_, i) => (
                <div key={i} className="rounded-2xl border border-amber-500/20 bg-gradient-to-br from-slate-800 to-slate-900 p-5 animate-pulse">
                  <div className="h-6 bg-white/10 rounded w-1/2 mb-3" />
                  <div className="h-2 bg-white/10 rounded w-full mb-2" />
                  <div className="h-2 bg-white/10 rounded w-3/4" />
                </div>
              ))}
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
              {activePlanets.map((item) => (
                <div
                  key={item.planet}
                  className="relative rounded-2xl overflow-hidden border border-amber-500/30 bg-gradient-to-br from-slate-800 to-slate-900 hover:border-amber-400/60 hover:shadow-[0_0_24px_rgba(251,191,36,0.12)] transition-all duration-300 group"
                >
                  <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />
                  <div className="p-5">
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2">
                        <span className="text-2xl">{item.symbol}</span>
                        <div>
                          <div className="font-bold text-white">{item.planet}</div>
                          <div className="text-xs text-gray-400">{item.position}</div>
                        </div>
                      </div>
                      <InfluenceBadge influence={item.influence} />
                    </div>

                    <div className="mb-3">
                      <div className="flex justify-between text-xs text-gray-400 mb-1">
                        <span>Bal (Strength)</span>
                        <span className="text-amber-400 font-medium">{item.strength}%</span>
                      </div>
                      <div className="w-full bg-white/10 rounded-full h-1.5">
                        <div
                          className={`h-1.5 rounded-full transition-all ${
                            item.strength >= 70 ? 'bg-gradient-to-r from-emerald-500 to-emerald-400' :
                            item.strength >= 45 ? 'bg-gradient-to-r from-amber-500 to-amber-400' :
                            'bg-gradient-to-r from-red-500 to-red-400'
                          }`}
                          style={{ width: `${item.strength}%` }}
                        />
                      </div>
                    </div>

                    <p className="text-xs text-gray-300 mb-3 leading-relaxed">{item.insight}</p>

                    <div className="flex flex-wrap gap-1">
                      {item.sectors.map(s => (
                        <span key={s} className="text-xs bg-white/10 text-gray-300 px-2 py-0.5 rounded-full border border-white/10">{s}</span>
                      ))}
                    </div>
                  </div>
                  <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/30 to-transparent" />
                </div>
              ))}
            </div>
          )}
        </section>

        <GoldDivider />

        <section className="mb-10">
          <div className="grid md:grid-cols-2 gap-6">
            <div className="relative rounded-2xl overflow-hidden border border-amber-500/30 bg-gradient-to-br from-slate-800 to-slate-900 shadow-[0_0_20px_rgba(251,191,36,0.07)]">
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />
              <div className="p-6">
                <h2 className="text-lg sm:text-xl font-bold text-white mb-1 flex items-center gap-2">
                  <Moon className="w-5 h-5 text-amber-400" />
                  Saptah ka Outlook
                </h2>
                <p className="text-gray-400 text-sm mb-5">Aaj se shuruaat — har din ke raajadhipati grah ke anusaar market mood</p>
                <div className="space-y-2">
                  {weekDays.map((day) => {
                    const isToday = day.dayIndex === todayDayIndex;
                    return (
                      <div
                        key={day.day}
                        className={`flex items-center gap-3 p-3 rounded-xl border transition-all ${
                          isToday
                            ? 'bg-amber-500/15 border-amber-500/40'
                            : 'bg-white/5 hover:bg-white/10 border-white/5 hover:border-amber-500/20'
                        }`}
                      >
                        <MoodIcon mood={day.mood} />
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2">
                            <span className={`font-semibold text-sm ${isToday ? 'text-amber-400' : 'text-white'}`}>{day.day}</span>
                            {isToday && <span className="text-xs bg-amber-500 text-slate-900 font-bold px-1.5 py-0.5 rounded-full">Aaj</span>}
                            <span className="text-xs text-gray-500">({day.ruler})</span>
                          </div>
                          <p className="text-xs text-gray-400 truncate">{day.note}</p>
                        </div>
                        <span className={`text-xs font-medium px-2 py-0.5 rounded-full flex-shrink-0 ${
                          day.mood === 'bullish' ? 'bg-emerald-500/20 text-emerald-400 border border-emerald-500/30' :
                          day.mood === 'bearish' ? 'bg-red-500/20 text-red-400 border border-red-500/30' :
                          'bg-amber-500/20 text-amber-400 border border-amber-500/30'
                        }`}>
                          {day.mood === 'bullish' ? 'Shubh' : day.mood === 'bearish' ? 'Ashubh' : 'Volatile'}
                        </span>
                      </div>
                    );
                  })}
                </div>
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/30 to-transparent" />
            </div>

            <div className="relative rounded-2xl overflow-hidden border border-amber-500/30 bg-gradient-to-br from-slate-800 to-slate-900 shadow-[0_0_20px_rgba(251,191,36,0.07)]">
              <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/40 to-transparent" />
              <div className="p-6">
                <h2 className="text-lg sm:text-xl font-bold text-white mb-1 flex items-center gap-2">
                  <TrendingUp className="w-5 h-5 text-emerald-400" />
                  Nifty 50 — Jyotish Zones
                </h2>
                <p className="text-gray-400 text-sm mb-5">Grahon ke aadhar par support aur resistance levels</p>
                {dataLoading ? (
                  <div className="space-y-3">
                    {[...Array(5)].map((_, i) => (
                      <div key={i} className="h-12 bg-white/5 rounded-xl animate-pulse" />
                    ))}
                  </div>
                ) : (
                  <div className="space-y-3">
                    {activeZones.map((zone) => (
                      <div
                        key={zone.id}
                        className={`flex items-center justify-between p-3 rounded-xl border ${
                          zone.zone_type === 'current'
                            ? 'bg-amber-500/10 border-amber-500/40'
                            : zone.zone_type === 'support'
                            ? 'bg-emerald-500/10 border-emerald-500/30'
                            : 'bg-red-500/10 border-red-500/30'
                        }`}
                      >
                        <div className="flex items-center gap-2">
                          <div className={`w-2 h-2 rounded-full ${
                            zone.zone_type === 'current' ? 'bg-amber-400' :
                            zone.zone_type === 'support' ? 'bg-emerald-400' : 'bg-red-400'
                          }`} />
                          <span className="text-sm text-gray-300">{zone.label}</span>
                        </div>
                        <span className={`font-bold text-sm ${
                          zone.zone_type === 'current' ? 'text-amber-400' :
                          zone.zone_type === 'support' ? 'text-emerald-400' : 'text-red-400'
                        }`}>
                          {zone.level}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
                {(tradingNote || !dataLoading) && (
                  <div className="mt-5 p-3 bg-amber-500/10 border border-amber-500/20 rounded-xl">
                    <p className="text-xs text-gray-300 leading-relaxed">
                      <strong className="text-amber-400">Astro Note:</strong>{' '}
                      {tradingNote || 'Jupiter aur Venus ka bullish prabhav market ko resistance ke upar le ja sakta hai. Stop-loss zaroor lagaen.'}
                    </p>
                  </div>
                )}
              </div>
              <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/30 to-transparent" />
            </div>
          </div>
        </section>

        <GoldDivider />

        <section>
          <div className="relative rounded-2xl overflow-hidden border border-amber-500/50 bg-gradient-to-br from-amber-950/80 via-slate-900 to-slate-900 text-white text-center shadow-[0_0_40px_rgba(251,191,36,0.12)]">
            <div className="absolute top-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/80 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 h-px bg-gradient-to-r from-transparent via-amber-400/80 to-transparent" />
            <div className="p-8 sm:p-10">
              <div className="flex items-center justify-center gap-2 mb-3">
                <div className="h-px w-12 bg-gradient-to-r from-transparent to-amber-400/60" />
                <Crown className="w-6 h-6 text-amber-400" />
                <div className="h-px w-12 bg-gradient-to-l from-transparent to-amber-400/60" />
              </div>
              <h3 className="text-2xl sm:text-3xl font-bold mb-2">Personal Trading Muhurat Janein</h3>
              <p className="text-gray-300 mb-2 max-w-xl mx-auto">
                Acharya Harish Purohit se apni janam kundli ke aadhar par personal trading muhurat aur planetary dasha analysis prapt karen.
              </p>
              <p className="text-amber-400/80 text-sm mb-6">30 saal ke anubhav ke saath — trusted by thousands</p>
              <a
                href="/astrologers"
                className="inline-flex items-center gap-2 bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-400 hover:to-amber-500 text-slate-900 font-bold px-8 py-3.5 rounded-full transition-all shadow-[0_4px_20px_rgba(251,191,36,0.35)] hover:shadow-[0_4px_30px_rgba(251,191,36,0.5)]"
              >
                Consultation Book Karen
                <TrendingUp className="w-4 h-4" />
              </a>
            </div>
          </div>
        </section>

      </div>
    </div>
  );
}
