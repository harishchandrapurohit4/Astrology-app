/*
  # Create AstroTrading Configuration Tables

  ## Summary
  This migration creates tables to store dynamic content for the AstroTrading page,
  allowing admins to update planet positions, Nifty zones, and market insights
  without code changes.

  ## New Tables
  1. `astro_planet_config` - Stores planet positions and market influence data
     - planet: Planet name (Sun, Moon, Mars, etc.)
     - symbol: Astrological symbol
     - position: Current zodiac position
     - influence: bullish/bearish/neutral
     - sectors: Array of affected market sectors
     - insight: Hindi market insight text
     - strength: Planet strength 1-100
     - config_date: Date this config applies to

  2. `astro_nifty_zones` - Stores Nifty support/resistance levels
     - label: Zone label
     - level: Nifty level (e.g. "22,500")
     - zone_type: support/resistance/current
     - config_date: Date this config applies to

  3. `astro_trading_notes` - Stores the astro note shown below Nifty zones
     - note_text: Hindi note text
     - config_date: Date this config applies to

  ## Security
  - RLS enabled on all tables
  - Public read access (unauthenticated users can view)
  - No write access via RLS (data managed via service role/migrations)
*/

CREATE TABLE IF NOT EXISTS astro_planet_config (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  planet text NOT NULL,
  symbol text NOT NULL DEFAULT '',
  position text NOT NULL DEFAULT '',
  influence text NOT NULL DEFAULT 'neutral' CHECK (influence IN ('bullish', 'bearish', 'neutral')),
  sectors text[] NOT NULL DEFAULT '{}',
  insight text NOT NULL DEFAULT '',
  strength integer NOT NULL DEFAULT 50 CHECK (strength >= 0 AND strength <= 100),
  config_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS astro_nifty_zones (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  label text NOT NULL,
  level text NOT NULL,
  zone_type text NOT NULL DEFAULT 'support' CHECK (zone_type IN ('support', 'resistance', 'current')),
  sort_order integer NOT NULL DEFAULT 0,
  config_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS astro_trading_notes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  note_text text NOT NULL DEFAULT '',
  config_date date NOT NULL DEFAULT CURRENT_DATE,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE astro_planet_config ENABLE ROW LEVEL SECURITY;
ALTER TABLE astro_nifty_zones ENABLE ROW LEVEL SECURITY;
ALTER TABLE astro_trading_notes ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can read planet config"
  ON astro_planet_config FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can read nifty zones"
  ON astro_nifty_zones FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Anyone can read trading notes"
  ON astro_trading_notes FOR SELECT
  TO anon, authenticated
  USING (true);
